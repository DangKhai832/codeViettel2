<?php
# Silence is golden.